# 남서울대학교 전자규정집 사이트 구조 (수집기 기준, 2026-11 확인)

수집기 `tools/nsu_rules_crawler.py`가 쓰는 주소와 응답 형식입니다. 사이트가 바뀌어 수집이 실패하면
이 문서와 실제 응답을 비교해 수집기를 고칩니다.

- 전자규정집(규정관리시스템, lmxsrv): `https://law.nsu.ac.kr` → `/lmxsrv/main/main.do`로 이동
  (학교 홈페이지 `nsu.ac.kr`의 '대학규정 및 학칙' 메뉴가 이 시스템을 엽니다)
- 청주대학교 규정관리시스템(`rule.cju.ac.kr`)과 같은 제품이며, 주소 끝이 `.srv` 대신 `.do`입니다.
- 화면 대부분이 AJAX로 채워지므로 주소를 바로 열면 "처리 중입니다" 빈 화면만 보일 수 있습니다. 아래 주소를 직접 부릅니다.
- 먼저 `/lmxsrv/main/main.do`를 한 번 열어 세션 쿠키를 받습니다.

## 1. 분류 트리 (JSON)

```
GET /lmxsrv/law/lawTreeNodes.do?LAWGROUP=1&PARENT=1&TREEDEPTH=1
→ [{"key":14,"title":"제1편 학교법인","folder":"1","lawType":"1",...}, {"key":17,"title":"제2편 학칙",...}, ...]
```

- `LAWGROUP=1`이 현행 규정, 최상위 `PARENT=1`(`lmx_const.js`의 `CONST_ROOT_KEY`). `PARENT`·`TREEDEPTH`를 바꿔 하위 노드를 받습니다.
- `folder:"1"`은 폴더(편·장·규정번호 폴더), `folder:"0"`이 규정입니다. 규정은 보통 `제N편 > (제N장 >) 규정번호 폴더 > 규정` 순서입니다.
  예: `제2편 학칙 > 제1장 남서울대학교 학칙 > 2-1-2 학칙 > 학칙(key 297)`
- 규정번호는 바로 위 폴더 이름 앞부분(`2-1-2`)에서 읽습니다. `[폐지] …` 폴더는 건너뜁니다.
- 2026-11 기준 규정 264개, 10편(학교법인·학칙·학사행정·부속기관·부설기관·부설연구소·위원회·기타·(9편 없음)·고등교육기관 관련 법령).
- **제10편 '고등교육기관 관련 법령'**은 고등교육법·사립학교법 등 국가 법령을 옮겨 둔 사본입니다. 규정에 넣으면 「고등교육법」 인용이
  국가법령정보센터 현행 법령 대신 이 사본으로 연결되므로 수집기는 기본으로 뺍니다(`--include-law-copies`로 포함).

## 2. 규정 상세 (담당부서·제·개정 연혁)

```
GET /lmxsrv/law/lawDetail_areaC.do?SEQ=<규정 key>&LAWGROUP=1
```

- `담당부서 : 교무처` 글자에서 담당부서를 읽습니다.
- 연혁 선택 상자 `<select id="histroySeq">`(철자 그대로)의 `<option value="1401" selected>`가 현행 판 번호(SEQ_HISTORY)이고,
  옵션 안 `showDate_new('20260810', …)`가 그 판의 날짜, 뒤따르는 `$("#dateVal"+1).append(' 개정')`이 제·개정 종류입니다.
- 본문은 이 화면의 iframe `lawFullContent.do?SEQ=…&SEQ_HISTORY=…`에 있습니다.

## 3. 본문 (HTML)

```
GET /lmxsrv/law/lawFullContent.do?SEQ=297&SEQ_HISTORY=1401
```

- `.lawname` 규정명, `.history` 제정·개정 줄(`제정 2011. 6. 27.`), `.chapter`·`.section` 장·절,
  `.JO` 조문(`제1조(교육목적)` 머리 다음 줄에 본문), `.hang`·`.ho` 항·호, `.addenda` 부칙(`부 칙 <2026. 8. 10.>`).
- 조문 옆 `.doc_btn`(조항 연혁·인쇄 아이콘)과 '연혁보기/숨기기' 버튼은 지웁니다.
- 끝의 `[별표/서식 파일]` 표: 파일 이름과 `javascript:fileDown('9703', 'attach');` 받기 링크.
- 수집기는 "제1조(목적)" 줄과 다음 본문 줄을 한 줄로 합칩니다(서원대·청주대 데이터와 같은 모양).

## 4. 개정정보 (원문·신구대비표 파일)

```
GET /lmxsrv/law/lawRevisionInfo.do?SEQ_HISTORY=1401
```

- `fileDown('1401', 'ori')` 원문(전문) HWP, `'rev'` 개정문, `'rea'` 개정이유, `'oldnew'` 신구대비표 HWP.
  수집기는 원문(ori)과 신구대비표(oldnew)만 첨부로 담습니다.

## 5. 파일 받기

```
GET /lmxsrv/fileDown.do?FILE_SEQ=9703&FILE_TYPE=attach     (ori·oldnew도 같은 방식)
→ Content-Disposition: attachment; fileName="%5B별표 1%5D …hwp"
```

- 사이트의 `fileDown()`(`/lmxmng/javascript/link.js`)은 POST 양식이지만 GET으로도 받아집니다.
  앱은 휴대폰에서 막히지 않도록 이 GET 주소를 링크로 씁니다(`rules.json`의 `fileDown.code` 안 `action` 주소를 읽음).

## 6. 원문 보기 링크

```
https://law.nsu.ac.kr/lmxsrv/law/lawFullView.do?SEQ=<규정 key>&SEQ_HISTORY=<판 번호>
```

- `SEQ`는 규정 key(트리 번호)이고 판이 바뀌어도 같습니다. `SEQ=1` 같은 번호만 넣으면 "문서가 삭제됐거나, 현행 문서정보가 없습니다"가 뜹니다.

## 수집 결과 기대값 (2026-11)

- 규정 253건(법령 사본 11건 제외), 조문 약 5,000개, 별표·첨부 약 860개, 실패 0건, 약 10분 소요(요청 간격 0.4초)
- `node tools/check_data.js`로 점검합니다.
